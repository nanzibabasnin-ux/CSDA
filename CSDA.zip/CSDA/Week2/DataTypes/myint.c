#include<stdio.h>

int age = 20;
printf("Age: %i\n", age);
