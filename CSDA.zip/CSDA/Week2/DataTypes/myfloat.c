#include <stdio.h>

int main(){

float height = 5.6;
printf("Height: %.2f\n", height);

return 0;
}

