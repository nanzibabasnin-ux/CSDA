#include<stdio.h>
#include<cs50.h>

int main(){
string grade = "Ariha";

printf("%s\n",grade);

return 0;
}
