#include<stdio.h>
#include<cs50.h>

int main(){


int marks = 20;

if (marks > 50)
{
    printf("Pass\n");
}
else
{
    printf("Fail\n");
}

return 0;
}
//Operators create Questions
//if uses the answers
