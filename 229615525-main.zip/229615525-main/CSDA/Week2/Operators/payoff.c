#include<stdio.h>


int marks = 75;

if (marks >= 50)
{
    printf("Pass\n");
}
else
{
    printf("Fail\n");
}


//Operators create Questions
//if uses the answers 
