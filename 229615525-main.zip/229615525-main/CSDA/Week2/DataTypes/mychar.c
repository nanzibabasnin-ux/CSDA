#include<stdio.h>
char grade = 'A';
printf("Grade: %c\n", grade);
