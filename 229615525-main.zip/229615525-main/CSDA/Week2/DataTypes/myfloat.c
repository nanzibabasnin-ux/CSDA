#include <stdio.h>

float height = 5.6;
printf("Height: %f\n", height);

