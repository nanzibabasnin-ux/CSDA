#include <stdio.h>

int main(void)
{
    int x = 5;
    printf("x is %i\n", x);
}
